package com.og.recyclerviewapplication

class Banner {
}