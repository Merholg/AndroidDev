package com.og.recyclerviewapplication

class PeopleAdapter {
}