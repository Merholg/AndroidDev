package com.og.recyclerviewapplication

class PeopleViewHolder {
}