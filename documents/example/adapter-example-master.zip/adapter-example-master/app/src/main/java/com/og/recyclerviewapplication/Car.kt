package com.og.recyclerviewapplication

data class Car(
    val brand: String,
    val color: String,
    val maxSpeed: Int
)