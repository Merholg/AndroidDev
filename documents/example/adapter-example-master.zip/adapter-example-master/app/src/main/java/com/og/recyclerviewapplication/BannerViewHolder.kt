package com.og.recyclerviewapplication

class BannerViewHolder {
}