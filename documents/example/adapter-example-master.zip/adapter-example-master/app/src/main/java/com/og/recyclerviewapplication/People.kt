package com.og.recyclerviewapplication

sealed class People
